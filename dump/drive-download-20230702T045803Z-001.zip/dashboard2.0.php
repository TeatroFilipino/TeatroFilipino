<!DOCTYPE html>
<html>
<head>
    <title>TENANT LANDLORD INFORMATION</title>
    <style>
        /* CSS styles for the page */
        body {
            font-family: Arial, sans-serif; /* Sets the font family for the entire page to Arial or a fallback sans-serif font */
            margin: 0; /* Removes the default margin around the body element */
            padding: 0; /* Removes any padding around the body element */
        }
        
        /* Styles for the header section */
        .header {
            text-align: center; /* Centers the text horizontally within the header element */
            background-color: #f2f2f2; /* Sets the background color of the header element to light gray */
            padding: 20px; /* Adds 20 pixels of padding to the top and bottom of the header element */
        }
        
        /* Styles for the navbar */
        .navbar {
            background-color: #333; /* Sets the background color of the navbar to dark gray */
            overflow: hidden; /* Ensures that any content overflowing the navbar is hidden */
            justify-content: space-between;
            padding: 10px;
        }
        
        .navbar ul {
            margin: 0; /* Removes the default margin around the ul (unordered list) element */
            padding: 0; /* Removes any padding around the ul element */
            list-style-type: none; /* Removes the bullet points from the list items */
            display: flex; /* Displays the list items horizontally in a flex container */
            justify-content: center; /* Centers the list items horizontally within the navbar */
        }
        
        .navbar li {
            margin: 0 10px; /* Adds a margin of 0 pixels on the top and bottom, and 10 pixels on the left and right of each list item */
        }
        
        .navbar a {
            color: #fff; /* Sets the color of the links in the navbar to white */
            text-decoration: none; /* Removes the underline decoration from the links */
            padding: 10px 20px; /* Adds 10 pixels of padding on the top and bottom, and 20 pixels on the left and right of each link */
        }
        
        /* Styles for the dropdown menu */
        .dropdown-content {
            display: none; /* Initially hides the dropdown content */
            position: absolute; /* Positions the dropdown content absolutely within the document flow */
            background-color: #f9f9f9; /* Sets the background color of the dropdown content to a light gray */
            min-width: 160px; /* Sets the minimum width of the dropdown content to 160 pixels */
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2); /* Adds a box shadow effect to the dropdown content */
            z-index: 1; /* Sets the stacking order of the dropdown content */
        }
        
        /* Display the dropdown menu on hover */
        .dropdown:hover .dropdown-content {
            display: block; /* Shows the dropdown content when hovering over the dropdown menu item */
        }
        
        .dropdown-content a {
            color: #333; /* Sets the color of the dropdown menu items to dark gray */
            padding: 10px 16px; /* Adds 10 pixels of padding on the top and bottom, and 16 pixels on the left and right of each dropdown menu item */
            text-decoration: none; /* Removes the underline decoration from the dropdown menu items */
            display: block; /* Displays the dropdown menu items as block elements */
        }
        
        .dropdown-content a:hover {
            background-color: #f1f1f1; /* Changes the background color of the dropdown menu items when hovering over them */
        }

        /* New style for the logo */
        .logo {
            position: absolute;
            top: 10px;
            left: 10px;
        }

    </style>
</head>
<body>
    <!-- New element for the logo -->
    <!-- insert logo.png URL in the src="" -->
    <img src=" " alt="Logo" class="logo">
    
    <!-- Start of the header section -->
    <div class="header">
        <h1>TENANT LANDLORD INFORMATION</h1>
    </div>
    <!-- End of the header section -->
    
    <!-- Start of the navbar section -->
    <div class="navbar">
        <ul>
            <!-- Navigation links -->
            <li><a href="dashboard2.0.php">Home</a></li>
            <li><a href="properties.php">Properties</a></li>
            <li><a href="units.php">Units</a></li>
            <li><a href="lease_dashboard.php">Lease Contracts</a></li>
            <li class="dropdown">
                <!-- Dropdown menu trigger -->
                <a href="#">More ▼ </a>
                <div class="dropdown-content">
                    <!-- Dropdown menu items -->
                    <a href="#">Unit Types</a>
                    <a href="#">Property Types</a>
                </div>
            </li>

        </ul>
    </div>
    <!-- End of the navbar section -->
    
    <!-- Your content goes here -->
    
</body>
</html>
