<?php

// to display the navbar in the webpage
include('navbar.html');
// include connection to the database
include('connection.php');

// query for retrieving records
$query = "SELECT unit_info.ParcelNo, property_info.PropAddress, unit_info.UnitNo, unit_types.UnitTypeID, unit_types.UnitDesc FROM unit_info JOIN property_info ON unit_info.ParcelNo = property_info.ParcelNo JOIN unit_types ON unit_info.UnitTypeID = unit_types.UnitTypeID";
// executing query
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Properties</title>
</head>
<body>
<table border="1" cellspacing="0" cellpadding="10">
    <tr>
        <th>Parcel No.</th>
        <th>Property Address</th>
        <th>Unit No.</th>
        <th>More Details</th>
    </tr>
    <?php
    // loops to display records (fetched as arrays with mysqli_fetch_assoc) into a table
    if (mysqli_num_rows($result) > 0) {
        while ($record = mysqli_fetch_assoc($result)) {
            ?>
        <tr>
            <td>
                <a href="unit_details.php?id=<?php echo $record["ParcelNo"]; ?>"><?php echo $record['ParcelNo']; ?></a>
            </td>
                <td><?php echo $record['PropAddress']; ?></td>
                <td><?php echo $record['UnitNo']; ?></td>
                <td align="center">
                <a href="unit_details.php?id=<?php echo urlencode($record["UnitDesc"]); ?>">
                View
                    </a>
                </td>
             </tr>
        <?php
        }
    } else { ?>
        <tr>
            <td colspan="4">No record found</td>
        </tr>
    <?php
    }
    $conn->close();
    ?>
</table>

<!-- button for adding a unit -->
<button onclick="document.location='add_unit.php'">Add Unit</button>

</body>
</html>
