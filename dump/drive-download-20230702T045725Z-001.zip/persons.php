<?php

// to display the navbar in the webpage
include('navbar.html');
// include connection to the database
include('connection.php');

// query for retrieving records
$query = "SELECT ID, Name, Address, GeneralNum, EmergencyNum, Email FROM persons";
// executing query
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="persons.css">
    <title>Persons</title>
</head>
<body>
<table border ="1" cellspacing="0" cellpadding="10">
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Address</th>
        <th>General Number</th>
        <th>Emergency Number</th>
        <th>Email Address</th>
        <th>More Details</th>
    </tr>
    <?php
    // loops to display records (fetched as arrays with mysqli_fetch_assoc) into a table
    if (mysqli_num_rows($result) > 0) {
    while($record = mysqli_fetch_assoc($result)) {
    ?>
    <tr>
        <td><?php echo $record['ID']; ?> </td>
        <td><?php echo $record['Name']; ?> </td>
        <td><?php echo $record['Address']; ?> </td>
        <td><?php echo $record['GeneralNum']; ?> </td>
        <td><?php echo $record['EmergencyNum']; ?> </td>
        <td><?php echo $record['Email']; ?> </td>
        <td align="center">
        <!-- adding the view hyperlink, setting the id as the ID -->
        <a href="person_details.php?id=<?php echo $record["ID"]; ?>">View</a>
        </td>
    <tr>
<?php
    }
} 
else { ?>
    <tr>
        <td colspan="8">No record found</td>
    </tr>
<?php 
} 
$conn->close();
?>
</table>

<!-- button for adding a person -->
<button onclick="document.location='add_persons.php'">Add Persons</button>

</body>
</html>