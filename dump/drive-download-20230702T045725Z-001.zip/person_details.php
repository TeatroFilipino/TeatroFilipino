<?php
// include the connection to the db
include('connection.php');

// to display the navbar in the webpage
include('navbar.html');

// identifier for which property to display, got from the view hyperlink
$id = $_REQUEST['id'];

// query to retrieve the record
$query = "SELECT * FROM persons, lease_info, property_info WHERE ID ='".$id."'";
$result = mysqli_query($conn, $query);

// fetching each record as arrays
$record = mysqli_fetch_assoc($result);

// retrieves tenant property details
$parcel_no = $record['ParcelNo'];
$unit_no = $record['UnitNo'];

// retrieves owner properties
$query_owner = "SELECT * FROM property_info WHERE OwnerID ='".$id."'";
$result_owner = mysqli_query($conn, $query_owner);
$owner_properties = mysqli_fetch_all($result_owner, MYSQLI_ASSOC);

// retrieves manager properties
$query_manager = "SELECT * FROM property_info WHERE ManagerID ='".$id."'";
$result_manager = mysqli_query($conn, $query_manager);
$manager_properties = mysqli_fetch_all($result_manager, MYSQLI_ASSOC);

// retrieves tenant name
$tenant_name = $record['Name'];

?>

<!DOCTYPE html>
<html>
<head>
    <title><?php echo $id; ?></title>
    <script src='delete.js'></script>
</head>
<body>
    <h1><a href="persons.php">Person</a></h1>
    <ul>
        <li>Person's ID: <?php echo $record['ID']; ?></li>
        <li>Person's Name: <?php echo $record['Name']; ?></li>
    </ul>

    <?php if ($parcel_no && $unit_no) { ?>
        <?php if (empty($owner_properties) && empty($manager_properties)) { ?>
            <h4>Tenant at <a href="lease.php?parcel=<?php echo $parcel_no; ?>&unit=<?php echo $unit_no; ?>"><?php echo $parcel_no; ?></a>, <?php echo $unit_no; ?></h4>
        <?php } ?>
        
    <?php } ?>

    <?php if (!empty($owner_properties)) { ?>
        <h4>Owner of</h4>
        <ul>
            <?php foreach ($owner_properties as $property) { ?>
                <?php if (isset($property['ParcelNo'])) { ?>
                    <li><a href="lease.php?parcel=<?php echo $property['ParcelNo']; ?><?php if (isset($property['UnitNo'])) { ?>&unit=<?php echo $property['UnitNo']; ?><?php } ?>"><?php echo $property['ParcelNo']; ?><?php if (isset($property['UnitNo'])) { ?>, <?php echo $property['UnitNo']; ?><?php } ?></a></li>
                <?php } ?>
            <?php } ?>
        </ul>
    <?php } ?>

    <?php if (!empty($manager_properties)) { ?>
        <h4>Manager of</h4>
        <ul>
            <?php foreach ($manager_properties as $property) { ?>
                <?php if (isset($property['ParcelNo'])) { ?>
                    <li><a href="lease.php?parcel=<?php echo $property['ParcelNo']; ?><?php if (isset($property['UnitNo'])) { ?>&unit=<?php echo $property['UnitNo']; ?><?php } ?>"><?php echo $property['ParcelNo']; ?><?php if (isset($property['UnitNo'])) { ?>, <?php echo $property['UnitNo']; ?><?php } ?></a></li>
                <?php } ?>
            <?php } ?>
        </ul>
    <?php } ?>
</body>
</html>
