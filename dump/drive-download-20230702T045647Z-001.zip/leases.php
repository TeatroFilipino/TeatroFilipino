<!DOCTYPE html>
<html>

<head>
    <title>Lease Contract</title>
    <link rel="stylesheet" type="text/css" href="dashboard.css">
    <link rel="stylesheet" type="text/css" href="leases.css">
    <link rel="stylesheet" type="text/css" href="navbar.css">
</head>

<body>
    <img src="images/logo.png" alt="Logo" class="logo">

    <div class="header">
        <h1>TENANT LANDLORD INFORMATION</h1>
    </div>

    <?php include 'navbar.php'; ?>

    <div id="search-bar">
        <form method="GET" action="">
            <input type="text" name="search" placeholder="Search...">
            <input type="submit" value="Search">
        </form>
    </div>

    <div class="lease_header">
        <h2>LEASE CONTRACTS</h2>
    </div>

    <table border="1" cellspacing="0" cellpadding="10">
        <tr>
            <th>Parcel Number</th>
            <th>Unit Number</th>
            <th>Tenant ID</th>
            <th>Start of Lease</th>
            <th>End of Lease</th>
            <th>Total Occupants</th>
        </tr>
        <?php
        // include connection to the database
        include('connection.php');

        // query for retrieving records
        $query = "SELECT ParcelNo, UnitNo, TenantID, StartOfLease, EndOfLease, TotalOccupants FROM lease_info";
        
        // executing query
        $result = mysqli_query($conn, $query);

        // loops to display records (fetched as arrays with mysqli_fetch_assoc) into a table
        if ($result && mysqli_num_rows($result) > 0) {
            while ($record = mysqli_fetch_assoc($result)) {
        ?>
        <tr>
            <td><?php echo $record['ParcelNo']; ?></td>
            <td><?php echo $record['UnitNo']; ?></td>
            <td><?php echo $record['TenantID']; ?></td>
            <td><?php echo $record['StartOfLease']; ?></td>
            <td><?php echo $record['EndOfLease']; ?></td>
            <td><?php echo $record['TotalOccupants']; ?></td>

                <!-- Additional code for more details, if required -->
            </td>
        </tr>
        <?php
            }
        } else {
            echo "<tr><td colspan='6'>No records found</td></tr>";
        }
        mysqli_close($conn);
        ?>
    </table>
    
    <button id="add-lease-button" onclick="document.location='add_lease.php'">Add a Lease</button>
    
</body>
</html>
