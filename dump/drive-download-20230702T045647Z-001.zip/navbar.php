<!DOCTYPE html>
<html>
<head>
  <title>TENANT LANDLORD INFORMATION</title>
  <link rel="stylesheet" type="text/css" href="navbar.css">
</head>
<body>
<div class="navbar">
        <ul>
            <li><a href="dashboard.php">Home</a></li>
            <li><a href="properties.php">Properties</a></li>
            <li><a href="units.php">Units</a></li>
            <li><a href="leases.php">Lease Contracts</a></li>
            <li class="dropdown">
                <a href="#">More ▼</a>
                <div class="dropdown-content">
                    <a href="#">Unit Types</a>
                    <a href="#">Property Types</a>
                </div>
            </li>
        </ul>
    </div>
