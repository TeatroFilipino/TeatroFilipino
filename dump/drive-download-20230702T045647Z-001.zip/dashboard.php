<!DOCTYPE html>
<html>
<head>
  <title>TENANT LANDLORD INFORMATION</title>
  <link rel="stylesheet" type="text/css" href="dashboard.css">
  <link rel="stylesheet" type="text/css" href="navbar.css">
</head>
<body>
  <img src="images/logo.png" alt="Logo" class="logo">

  <div class="header">
    <h1>TENANT LANDLORD INFORMATION</h1>
  </div>

  <?php include 'navbar.php'; ?>

  <div class="container">
    <div class="box">
      <img src="images/properties.png" alt="Property">
      <h3>PROPERTIES</h3>
    </div>
    <div class="box">
      <img src="images/units.png" alt="Units">
      <h3>UNITS</h3>
    </div>
    <div class="box">
      <img src="images/leases.png" alt="Leases">
      <h3>LEASES</h3>
    </div>
    <div class="box">
      <img src="images/persons.png" alt="Persons">
      <h3>PERSONS</h3>
    </div>
  </div>

  <!-- Your content goes here -->

</body>
</html>
